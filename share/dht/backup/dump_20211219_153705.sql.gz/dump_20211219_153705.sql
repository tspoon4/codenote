--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.24
-- Dumped by pg_dump version 9.5.24

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: dht_crawl; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dht_crawl (
    start timestamp with time zone NOT NULL,
    stop timestamp with time zone NOT NULL,
    target bytea NOT NULL,
    total integer NOT NULL,
    timeout integer NOT NULL,
    errors integer NOT NULL,
    sample_ext integer NOT NULL,
    peers_found integer NOT NULL
);


--
-- Name: dht_geoip; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dht_geoip (
    "time" timestamp with time zone NOT NULL,
    subnet bytea NOT NULL,
    country character(2) NOT NULL,
    name character varying(64) NOT NULL
);


--
-- Name: dht_meta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dht_meta (
    start timestamp with time zone NOT NULL,
    stop timestamp with time zone NOT NULL,
    total integer NOT NULL,
    timeout integer NOT NULL,
    errors integer NOT NULL,
    ut_metadata integer NOT NULL,
    torrents_found integer NOT NULL
);


--
-- Name: dht_peers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dht_peers (
    "time" timestamp with time zone NOT NULL,
    peer bytea NOT NULL,
    hash bytea NOT NULL
);


--
-- Name: dht_torrents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dht_torrents (
    "time" timestamp with time zone NOT NULL,
    hash bytea NOT NULL,
    name character varying(256) NOT NULL,
    files integer NOT NULL,
    size bigint NOT NULL
);


--
-- Data for Name: dht_crawl; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dht_crawl (start, stop, target, total, timeout, errors, sample_ext, peers_found) FROM stdin;
\.


--
-- Data for Name: dht_geoip; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dht_geoip ("time", subnet, country, name) FROM stdin;
\.


--
-- Data for Name: dht_meta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dht_meta (start, stop, total, timeout, errors, ut_metadata, torrents_found) FROM stdin;
\.


--
-- Data for Name: dht_peers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dht_peers ("time", peer, hash) FROM stdin;
\.


--
-- Data for Name: dht_torrents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dht_torrents ("time", hash, name, files, size) FROM stdin;
\.


--
-- Name: dht_geoip_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dht_geoip
    ADD CONSTRAINT dht_geoip_pkey PRIMARY KEY (subnet);


--
-- Name: dht_torrents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dht_torrents
    ADD CONSTRAINT dht_torrents_pkey PRIMARY KEY (hash);


--
-- Name: dht_peers_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dht_peers_ip ON public.dht_peers USING btree (peer);


--
-- Name: dht_peers_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX dht_peers_key ON public.dht_peers USING btree (hash, peer);


--
-- Name: dht_torrents_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dht_torrents_name ON public.dht_torrents USING gin (name public.gin_trgm_ops);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: -
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

